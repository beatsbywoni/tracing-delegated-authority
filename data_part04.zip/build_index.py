"""Build statute/decree article index and delegation map from raw archive."""
import json, glob, re, collections
RAW='archive/data/raw/'
def flat(u):
    parts=[u.get('조문내용','')]
    hs=u.get('항') or []
    if isinstance(hs,dict): hs=[hs]
    for h in hs:
        parts.append(h.get('항내용','') if isinstance(h,dict) else str(h))
        hos=(h.get('호') if isinstance(h,dict) else None) or []
        if isinstance(hos,dict): hos=[hos]
        for ho in hos:
            parts.append(ho.get('호내용',''))
            moks=ho.get('목') or []
            if isinstance(moks,dict): moks=[moks]
            for m in moks:
                mc=m.get('목내용','')
                if isinstance(mc,list): mc=' '.join(x if isinstance(x,str) else ' '.join(x) for x in mc)
                parts.append(mc)
    out=[]
    for p in parts:
        if isinstance(p,list): p=' '.join(x if isinstance(x,str) else ' '.join(x) for x in p)
        out.append(str(p).strip())
    return '\n'.join(x for x in out if x)
laws={}; arts={}
for f in sorted(glob.glob(RAW+'law_*.json')):
    d=json.load(open(f))['법령']; b=d['기본정보']
    lid=b['법령ID']; name=b['법령명_한글']; kind=b['법종구분']['content']
    laws[lid]=dict(id=lid,name=name,kind=kind,eff=b.get('시행일자'))
    us=d['조문']['조문단위']
    if isinstance(us,dict): us=[us]
    for u in us:
        if u.get('조문여부')!='조문': continue
        no=u['조문번호']; br=u.get('조문가지번호','') or ''
        key=f"{lid}:{no}" + (f"-{br}" if br else '')
        arts[key]=dict(law=lid,no=no,br=br,title=u.get('조문제목',''),text=flat(u))
# delegation map: source law article -> target decree/rule article
deleg=[]
for f in sorted(glob.glob(RAW+'deleg_*.json')):
    lid=f.split('_')[-1][:-5]
    d=json.load(open(f)).get('lsDelegated',{}).get('법령',{})
    infos=d.get('위임조문정보') or []
    if isinstance(infos,dict): infos=[infos]
    for inf in infos:
        src_no=inf.get('조문정보',{}).get('조문번호') if isinstance(inf.get('조문정보'),dict) else None
        wi=inf.get('위임정보') or []
        if isinstance(wi,dict): wi=[wi]
        for w in wi:
            tl=w.get('위임법령조문정보') or []
            if isinstance(tl,dict): tl=[tl]
            for t in tl:
                deleg.append(dict(src_law=lid,src_no=src_no,src_par=t.get('조항호목'),kind=w.get('위임구분'),
                    tgt_title=w.get('위임법령제목'),tgt_serial=w.get('위임법령일련번호'),
                    tgt_no=t.get('위임법령조문번호'),tgt_br=t.get('위임법령조문가지번호',''),line=t.get('라인텍스트')))
json.dump(dict(laws=laws,arts=arts,deleg=deleg),open('work/index.json','w'),ensure_ascii=False)
print(len(laws),len(arts),len(deleg))
print(collections.Counter(x['kind'] for x in laws.values()))
print(deleg[0])
