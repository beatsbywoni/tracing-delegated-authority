import json,sys
a,b=int(sys.argv[1]),int(sys.argv[2]); T=int(sys.argv[3])
for i,l in enumerate(open('s2_chunk015.jsonl')):
    if not a<=i<b: continue
    d=json.loads(l)
    print('=====',i,d['packet_id'],d['rule_title'],d['rule_type'])
    print('ART:',d['article_text'])
    print('PUR:',d['purpose_clause'][:500])
    for k in ['cited_provisions','other_candidate_provisions','related_provisions_in_cited_laws']:
        for p in d[k]:
            print(k[:5],p.get('key'),p.get('law'),p.get('article'),'DF:',p.get('delegated_from'),'DT:',p.get('delegates_to'))
            print('   ',p.get('text','')[:T].replace('\n',' / '))
    print('NOART:',d['cited_laws_without_article'],'UNRES:',d['unresolved_citations'])
