"""Merge external (other-ministry) laws/admin rules into index.json -> index_ext.json"""
import json, glob, re, csv
from build_index import flat  # reuse
I=json.load(open('work/index.json'))
laws, arts, deleg = I['laws'], I['arts'], I['deleg']
RAW='/mnt/user-data/uploads/23. 위임입법 논문/재분석_외부법령수집_codex/raw_external/'
aliases={}
for f in sorted(glob.glob(RAW+'*.json')):
    d=json.load(open(f)); tgt=d['target']; nm=d['name']; lid='X'+str(d['serial'])
    if tgt=='law':
        L=d['body']['법령']; b=L['기본정보']
        laws[lid]=dict(id=lid,name=nm,kind=b['법종구분']['content'] if isinstance(b.get('법종구분'),dict) else str(b.get('법종구분')),eff=b.get('시행일자'),external=True)
        us=(L.get('조문') or {}).get('조문단위') or []
        if isinstance(us,dict): us=[us]
        for u in us:
            if u.get('조문여부')!='조문': continue
            no=u['조문번호']; br=u.get('조문가지번호','') or ''
            arts[f"{lid}:{no}"+(f"-{br}" if br else '')]=dict(law=lid,no=no,br=br,title=u.get('조문제목',''),text=flat(u))
    else:
        A=d['body']['AdmRulService']; b=A.get('행정규칙기본정보',{})
        laws[lid]=dict(id=lid,name=nm,kind=b.get('행정규칙종류','행정규칙'),eff=b.get('시행일자'),external=True)
        cs=(A.get('조문') or {}).get('조문내용') or A.get('조문내용') or []
        if isinstance(cs,str): cs=[cs]
        for c in cs:
            if isinstance(c,list): c=' '.join(map(str,c))
            m=re.match(r'\s*제\s*(\d+)\s*조(?:의\s*(\d+))?\s*(?:\(([^)]*)\))?',c)
            if not m: continue
            no,br=m.group(1),m.group(2) or ''
            arts[f"{lid}:{no}"+(f"-{br}" if br else '')]=dict(law=lid,no=no,br=br,title=m.group(3) or '',text=c)
    aliases[re.sub(r'[\s·ㆍ]','',d['query'])]=lid
I['aliases']=aliases
json.dump(I,open('work/index_ext.json','w'),ensure_ascii=False)
print(len(laws),len(arts),len(aliases), sum(1 for k in arts if k.startswith('X')))
