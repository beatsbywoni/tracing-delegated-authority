"""Rule articles + citation extraction/resolution."""
import json, re, collections
I=json.load(open('work/index_ext.json')); laws=I['laws']; arts=I['arts']
def norm(s): return re.sub(r'[\s·ㆍ]','',s)
name2id={norm(v['name']):k for k,v in laws.items()}; name2id.update({k:v for k,v in I.get('aliases',{}).items() if k not in name2id})
rules=[json.loads(l) for l in open('/root/.claude/uploads/87d9242b-9c3e-518b-8c26-9314beffaeeb/70792d2a-admrules.jsonl')]
KEEP={'훈령','예규','고시','지침'}
ART=re.compile(r'^\s*제\s*(\d+)\s*조(?:의\s*(\d+))?\s*(?:\(([^)]*)\))?')
REF=re.compile(r'(「[^」]{2,80}」|같은\s*법\s*시행령|같은\s*법\s*시행규칙|같은\s*법|같은\s*영|같은\s*규칙|동법\s*시행령|동법\s*시행규칙|동법|동령|(?<![가-힣])법|(?<![가-힣])영|(?<![가-힣])규칙)\s*제\s*(\d+)\s*조(?:\s*의\s*(\d+))?((?:\s*제\s*\d+\s*항)?(?:\s*제\s*\d+\s*호)?)')
ENUM=re.compile(r'\s*(?:,|및|ㆍ|·|와|과|또는|그리고)\s*제\s*(\d+)\s*조(?:\s*의\s*(\d+))?(?:\s*제\s*\d+\s*항)?(?:\s*제\s*\d+\s*호)?(?:\s*(?:각\s*호|단서|후단|본문))?')
_last=[0]
def pos_ok(t,em):
    # contiguous enumeration: each item must start where the previous ended
    if em.start()==0: _last[0]=em.end(); return 0
    if em.start()==_last[0]: _last[0]=em.end(); return em.start()
    return -1
DEF=re.compile(r'「([^」]+)」[^「」]{0,40}?\(이하\s*["“”\'‘’]?([^"“”\'‘’)]{1,10})["“”\'‘’]?\s*(?:이)?라\s*한다\)')
out=[]
for r in rules:
    if r['행정규칙종류'] not in KEEP: continue
    arts_r=r['_본문'].get('조문내용') or []
    if isinstance(arts_r,str): arts_r=[arts_r]
    full=' '.join(arts_r)
    defs={}
    for m in DEF.finditer(full):
        defs[m.group(2).strip()]=m.group(1)
    purpose=next((a for a in arts_r if ART.match(a) and ART.match(a).group(1)=='1'),'')
    for idx,a in enumerate(arts_r):
        m=ART.match(a)
        if not m: continue
        refs=[]; last=None
        a0=a
        a=re.sub(r'(」)\s*\((?:이하|다음)[^)]{0,40}\)',r'\1',a)
        for rm in REF.finditer(a):
            tok=re.sub(r'\s','',rm.group(1)); no=rm.group(2); br=rm.group(3) or ''
            if tok.startswith('「'):
                nm=tok[1:-1]; last=nm
            elif tok in ('같은법','동법'): nm=last
            elif tok in ('같은법시행령','동법시행령','같은영','동령'):
                nm=(re.sub(r'\s*시행(령|규칙)$','',last)+' 시행령') if last else None
            elif tok in ('같은법시행규칙','동법시행규칙','같은규칙'):
                nm=(re.sub(r'\s*시행(령|규칙)$','',last)+' 시행규칙') if last else None
            else:
                nm=defs.get(tok)
                if nm is None:
                    continue  # bare 법/영 without definition: skip
            if not nm: continue
            lid=name2id.get(norm(nm))
            key=None
            if lid:
                key=f"{lid}:{no}"+(f"-{br}" if br else '')
                if key not in arts: key=key+'?'
            refs.append(dict(raw=rm.group(0).strip(),law=nm,law_id=lid,key=key,par=re.sub(r'\s','',rm.group(4) or '')))
            tail=a[rm.end():rm.end()+200]
            for em in ENUM.finditer(tail):
                if em.start()!=pos_ok(tail,em): break
                no2=em.group(1); br2=em.group(2) or ''
                k2=None
                if lid:
                    k2=f"{lid}:{no2}"+(f"-{br2}" if br2 else '')
                    if k2 not in arts: k2=k2+'?'
                refs.append(dict(raw=nm+' '+em.group(0).strip(' ,'),law=nm,law_id=lid,key=k2,par='',enum=True))
        for lm in re.finditer(r'「([^」]{2,80})」(?!\s*제\s*\d+\s*조)',a):
            nm=lm.group(1); lid=name2id.get(norm(nm))
            refs.append(dict(raw=lm.group(0),law=nm,law_id=lid,key=None,par='',law_level=True))
        out.append(dict(uid=f"{r['행정규칙일련번호']}#{m.group(1)}"+(f"-{m.group(2)}" if m.group(2) else ''),
            rule_id=r['행정규칙일련번호'],rule_title=r['행정규칙명'],rule_type=r['행정규칙종류'],
            art_no=m.group(1)+(f"의{m.group(2)}" if m.group(2) else ''),art_title=m.group(3) or '',
            text=a0,purpose=purpose,refs=refs))
json.dump(out,open('work/articles_v2.json','w'),ensure_ascii=False)
n=len(out); withref=sum(1 for x in out if x['refs']); res=sum(1 for x in out for y in x['refs'] if y['key'] and not y['key'].endswith('?'))
tot=sum(len(x['refs']) for x in out); ext=sum(1 for x in out for y in x['refs'] if not y['law_id'])
print('articles',n,'with refs',withref,'refs',tot,'resolved',res,'external/unresolved law',ext)
x=[a for a in out if a['uid']=='2100000250466#24'][0]; print(x['refs'])
print(collections.Counter(y['law'] for x in out for y in x['refs'] if not y['law_id']).most_common(15))
