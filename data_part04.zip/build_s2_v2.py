"""Reading packets: rule article + cited provisions + delegation chain context."""
import json, re, random, collections, hashlib
I=json.load(open('work/index_ext.json')); laws=I['laws']; arts=I['arts']; deleg=I['deleg']
A=json.load(open('work/articles_v2.json'))
def norm(s):
    if isinstance(s,list): s=s[0] if s else ''
    return re.sub(r'[\s·ㆍ]','',s or '')
name2id={norm(v['name']):k for k,v in laws.items()}
def T(s,n): return s if len(s)<=n else s[:n]+' …[이하 생략]'
up=collections.defaultdict(list); down=collections.defaultdict(list)
for d in deleg:
    if d['kind'] not in ('시행령','시행규칙'): continue
    tid=name2id.get(norm(d['tgt_title']))
    if not tid or not d['tgt_no']: continue
    tk=f"{tid}:{d['tgt_no']}"+(f"-{d['tgt_br']}" if d['tgt_br'] else '')
    m=re.match(r'제(\d+)조(?:의(\d+))?',d['src_par'] or '')
    if not m: continue
    sk=f"{d['src_law']}:{m.group(1)}"+(f"-{m.group(2)}" if m.group(2) else '')
    up[tk].append((sk,d['src_par'],d['line'])); down[sk].append((tk,d['src_par'],d['line']))
def art_view(k,n=4000):
    a=arts[k]; L=laws[a['law']]
    return dict(key=k,law=L['name'],kind=L['kind'],article=f"제{a['no']}조"+(f"의{a['br']}" if a['br'] else ''),title=a['title'],text=T(a['text'],n))
MINI=re.compile(r'(교육부장관|장관|교육감)[^。.\n]{0,30}(정하|정한|정해|정할|고시|지정|따로)|교육부령|부령으로')
def family(lid):
    base=re.sub(r'\s*시행(령|규칙)$','',laws[lid]['name'])
    return [k for k,v in laws.items() if re.sub(r'\s*시행(령|규칙)$','',v['name'])==base]
import math
DF=collections.Counter()
ATOK={}
for key,v in arts.items():
    ts=set(re.findall(r'[가-힣]{2,}',v['title']+' '+v['text'])); ATOK[key]=ts; DF.update(ts)
NART=len(arts)
def idf(t): return math.log(NART/(1+DF[t]))
STOP={'경우','다음','관한','따른','한다','있다','같은','이하','해당','사항','필요한','정하는','대통령령으로','교육부장관','장관','규정','제1항','이','법','영'}
def candidates(a, fam_ids, exclude, k=4):
    toks=set(re.findall(r'[가-힣]{2,}',a['art_title']+' '+a['text']))-STOP
    sc=[]
    for key,v in arts.items():
        if v['law'] not in fam_ids or key in exclude: continue
        if not MINI.search(v['text']): continue
        txt=v['title']+' '+v['text']
        ov={t for t in toks if t in txt}
        s=sum(idf(t) for t in ov) + 2*sum(idf(t) for t in ov if t in v['title'])
        if s>=8: sc.append((s,key))
    return [art_view(x[1],700) for x in sorted(sc,reverse=True)[:k]]
def related(a, law_ids, exclude, k=2):
    toks=set(re.findall(r'[가-힣]{2,}',a['art_title']+' '+a['text']))-STOP
    sc=[]
    for key,v in arts.items():
        if v['law'] not in law_ids or key in exclude: continue
        txt=v['title']+' '+v['text']
        ov={t for t in toks if t in txt}
        s=sum(idf(t) for t in ov) + 2*sum(idf(t) for t in ov if t in v['title'])
        if s>=10: sc.append((s,key))
    return [art_view(x[1],900) for x in sorted(sc,reverse=True)[:k]]
def packet(a):
    cited=[]; seen=set(); unresolved=[]; fam=set(); cited_laws=set()
    for r in a['refs']:
        if not r['law_id']: unresolved.append(dict(raw=r['raw'],law=r['law'],reason='law outside collected corpus')); continue
        if r.get('law_level'):
            fam.update(family(r['law_id'])); cited_laws.add(laws[r['law_id']]['name']); continue
        if not r['key'] or r['key'].endswith('?'): unresolved.append(dict(raw=r['raw'],law=r['law'],reason='article not found in corpus snapshot')); continue
        fam.update(family(r['law_id']))
        if r['key'] in seen: continue
        seen.add(r['key']); v=art_view(r['key']); v['cited_as']=r['raw']
        v['delegated_from']=[dict(src=art_view(s,1000),src_paragraph=p,line=l) for s,p,l in list(dict.fromkeys(up.get(r['key'],[])))[:3] if s in arts]
        dn=[(t,p,l) for t,p,l in dict.fromkeys(down.get(r['key'],[])) if t in arts]
        dn.sort(key=lambda x: 0 if MINI.search(arts[x[0]]['text']) else 1)
        v['delegates_to']=[dict(tgt=art_view(t,700),src_paragraph=p,line=l) for t,p,l in dn[:3]]
        cited.append(v)
    # purpose-clause citations as fallback context
    pc=[]
    if a['purpose'] and a['purpose']!=a['text']:
        for r in json.loads(json.dumps(a.get('purpose_refs',[]))): pass
    npc=0
    for r in purpose_refs.get(a['rule_id'],[]):
        if r['law_id']:
            fam.update(family(r['law_id']))
        if a.get('refs_from_purpose') or a['art_no']=='1': continue
        if not r['law_id'] or r.get('law_level') or not r['key'] or r['key'].endswith('?') or r['key'] in seen or npc>=6: continue
        seen.add(r['key']); npc+=1; v=art_view(r['key'],2500); v['cited_as']=r['raw']; v['cited_via']='purpose_clause'
        v['delegated_from']=[dict(src=art_view(s_,1000),src_paragraph=p,line=l) for s_,p,l in list(dict.fromkeys(up.get(r['key'],[])))[:3] if s_ in arts]
        dn=[(t,p,l) for t,p,l in dict.fromkeys(down.get(r['key'],[])) if t in arts]
        dn.sort(key=lambda x: 0 if MINI.search(arts[x[0]]['text']) else 1)
        v['delegates_to']=[dict(tgt=art_view(t,700),src_paragraph=p,line=l) for t,p,l in dn[:3]]
        cited.append(v)
    cand=candidates(a,fam,seen,2) if fam else []
    lawlevel={r['law_id'] for r in a['refs'] if r.get('law_level') and r['law_id']}|{r['law_id'] for r in purpose_refs.get(a['rule_id'],[]) if r.get('law_level') and r['law_id']}
    rel=related(a,lawlevel,seen|{c['key'] for c in cand}) if lawlevel else []
    return dict(packet_id=a['uid'],rule_title=a['rule_title'],rule_type=a['rule_type'],article=f"제{a['art_no']}조",
        article_title=a['art_title'],article_text=T(a['text'],3500),purpose_clause=T(a['purpose'],1500),
        cited_provisions=cited,cited_laws_without_article=sorted(cited_laws),unresolved_citations=unresolved,other_candidate_provisions=cand,related_provisions_in_cited_laws=rel)
# purpose refs: attach rule-level purpose citations to articles without their own refs
byrule=collections.defaultdict(list)
purpose_refs={}
for a in A: byrule[a['rule_id']].append(a)
for rid,lst in byrule.items():
    p=next((x for x in lst if x['art_no']=='1'),None)
    purpose_refs[rid]=list(p['refs']) if p else []
    for a in lst:
        if not a['refs'] and p and p['refs'] and a is not p:
            a['refs']=p['refs']; a['refs_from_purpose']=True

sel=json.load(open('work/s2_selected_ids.json'))
neg=[a['uid'] for a in A if a['rule_id']=='2100000274694' and a['art_no'] not in ('1',)][:3]
ids=list(dict.fromkeys(sel+neg))
byid={a['uid']:a for a in A}
import os
os.makedirs('work/s2c/chunks',exist_ok=True); os.makedirs('work/s2c/out',exist_ok=True)
P=[packet(byid[i]) for i in ids]
random.seed(20261019); random.shuffle(P)
with open('work/s2c/s2_packets.jsonl','w') as f:
    for p in P: f.write(json.dumps(p,ensure_ascii=False)+'\n')
# chunk by size ~90k chars
chunks=[]; cur=[]; size=0
for p in P:
    l=json.dumps(p,ensure_ascii=False)
    if size+len(l)>90000 and cur: chunks.append(cur); cur=[]; size=0
    cur.append(l); size+=len(l)
if cur: chunks.append(cur)
for k,c in enumerate(chunks):
    open(f'work/s2c/chunks/s2_chunk{k+1:03d}.jsonl','w').write('\n'.join(c)+'\n')
json.dump(dict(neg_controls=neg,positive='2100000250466#24'),open('work/s2c/s2_controls.json','w'))
sz=[len(json.dumps(p,ensure_ascii=False)) for p in P]
print(len(P),'chunks',len(chunks),'chars',sum(sz),'max',max(sz))
print('unresolved-only packets',sum(1 for p in P if not p['cited_provisions'] and p['unresolved_citations']))
print('no citation at all',sum(1 for p in P if not p['cited_provisions'] and not p['cited_laws_without_article'] and not p['unresolved_citations']))
