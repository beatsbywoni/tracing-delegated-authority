import json,glob,sys,os
base='work/s2c/'
reader=sys.argv[1]
bad=[];done=0
for k in range(1,65):
    c=base+f'rchunks/r_chunk{k:03d}.jsonl'; o=base+f'gpt/gpt_r_chunk{k:03d}.jsonl'
    ids=[json.loads(l)['packet_id'] for l in open(c) if l.strip()]
    if not os.path.exists(o): continue
    got=[]
    for l in open(o):
        l=l.strip()
        if not l: continue
        try: got.append(json.loads(l)['packet_id'])
        except Exception: bad.append((k,'parse'))
    if set(got)!=set(ids): bad.append((k,len(ids),len(got),len(set(ids)-set(got))))
    else: done+=1
print('complete',done,'problems',bad)
