# 판례·결정례 대조 판독 지시문 (v1.0)

각 판독지(pair)는 교육부 행정규칙 하나와, 그 제목이 본문에 나오는 판례·헌재결정·법령해석례·행정심판재결례 하나의 짝이다. `decision_summary`(요지)와 `excerpts_around_title`(제목 앞뒤 발췌)만 근거로 판단한다. 외부 지식은 쓰지 않는다. 결정문이 말하는 것만 기록한다.

## 판정 항목
- `role`: 결정문에서 이 행정규칙이 하는 역할
  - `assessed_binding`: 규칙(또는 특정 조항)의 대외적 구속력, 법규성, 위임 근거, 효력 유무를 판단함
  - `applied`: 규칙을 처분 근거나 판단 기준으로 적용·인용했으나 구속력·위임을 따지지 않음
  - `mentioned`: 사실관계·경위에서 언급만 함
  - `other_rule`: 같은 제목의 다른 규칙(다른 기관·다른 시기)이거나 이 규칙이 아님
- `holding` (`role`이 `assessed_binding`일 때만, 아니면 `na`):
  - `no_external_force`: 대외적 구속력 없음, 내부 사무처리 기준에 불과, 위임 범위 일탈, 근거로 삼을 수 없음
  - `binding_by_delegation`: 법령의 위임에 따라 법령과 결합해 대외적 구속력 있음
  - `binding_other`: 다른 근거(자기구속, 재량준칙의 평등 원칙 등)로 외부효 인정
  - `mixed`: 조항별로 다름
  - `unclear`
- `articles_addressed`: 결정문이 특정한 조항(예: "제24조"). 없으면 빈 목록
- `evidence_quote`: 판단을 보여 주는 결정문 문구 40자 이내
- `date`: 결정일(알 수 있으면)
- `rationale`: 40단어 이내

## 출력
판독지 한 건마다 JSON 한 줄(입력 순서):
```json
{"pair_id": "...", "role": "...", "holding": "...", "articles_addressed": [], "evidence_quote": "...", "date": "...", "rationale": "...", "reader": "<지정 값>"}
```
