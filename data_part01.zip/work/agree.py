"""Sonnet-GPT agreement on stage-2 readings.
usage: python3 agree.py v1   -> v1 packets (s2b), Sonnet v1 vs GPT v1
       python3 agree.py v2   -> final packets: unchanged ids from v1 readings, changed ids from v2 (s2c) readings
Writes discordant ids to s2c/discordant_<mode>.json
"""
import json, glob, sys, collections
W = 'work/'
mode = sys.argv[1] if len(sys.argv) > 1 else 'v1'
def rd(pat):
    R = {}
    for f in sorted(glob.glob(W + pat)):
        for l in open(f):
            if l.strip():
                o = json.loads(l); R[o['packet_id']] = o
    return R
S1 = rd('s2b/out/sonnet_s2_chunk*.jsonl'); G1 = rd('s2b/gpt/gpt_s2_chunk*.jsonl')
changed = set(json.load(open(W + 's2c/changed_ids.json')))
if mode == 'v1':
    S, G = S1, G1
else:
    S2 = rd('s2c/out/sonnet_r_chunk*.jsonl'); G2 = rd('s2c/gpt/gpt_r_chunk*.jsonl')
    S = {k: (S2[k] if k in changed else v) for k, v in S1.items() if (k not in changed or k in S2)}
    G = {k: (G2[k] if k in changed else v) for k, v in G1.items() if k not in changed}
    G.update({k: v for k, v in G2.items()})
ids = sorted(set(S) & set(G))
B = {'B1', 'B2', 'B3', 'F1'}
def kappa(a, b):
    n = len(a); po = sum(x == y for x, y in zip(a, b)) / n
    ca, cb = collections.Counter(a), collections.Counter(b)
    pe = sum(ca[k] * cb[k] for k in set(ca) | set(cb)) / n / n
    return (po - pe) / (1 - pe) if pe < 1 else 1.0, po
def show(name, f):
    a = [f(S[i]) for i in ids]; b = [f(G[i]) for i in ids]
    k, po = kappa(a, b); print(f'{name:28s} kappa={k:.3f} agree={po:.3f}')
print(mode, 'common packets', len(ids))
show('article_status (9 codes)', lambda o: o['article_status'])
show('addressee', lambda o: o['addressee'])
show('broken (B1/B2/B3/F1) y/n', lambda o: o['article_status'] in B)
show('5-way: N/traced/X/U/broken', lambda o: 'broken' if o['article_status'] in B else ('traced' if o['article_status'] in ('T1', 'T2') else o['article_status']))
cs = collections.Counter(S[i]['article_status'] for i in ids); cg = collections.Counter(G[i]['article_status'] for i in ids)
print('code   sonnet  gpt')
for c in ['N', 'T1', 'T2', 'X', 'U', 'B1', 'B2', 'B3', 'F1']: print(f'{c:5s} {cs[c]:6d} {cg[c]:5d}')
both = [i for i in ids if S[i]['article_status'] in B and G[i]['article_status'] in B]
either = [i for i in ids if S[i]['article_status'] in B or G[i]['article_status'] in B]
print('broken: both', len(both), 'either', len(either))
ct = collections.Counter((S[i]['article_status'], G[i]['article_status']) for i in ids if S[i]['article_status'] != G[i]['article_status'])
print('top disagreements (sonnet, gpt):', ct.most_common(12))
disc = [i for i in ids if (S[i]['article_status'] in B) != (G[i]['article_status'] in B) or
        ((S[i]['article_status'] in B) and S[i]['article_status'] != G[i]['article_status']) or
        ({S[i]['article_status'], G[i]['article_status']} & {'U'} and S[i]['article_status'] != G[i]['article_status'])]
json.dump(disc, open(W + f's2c/discordant_{mode}.json', 'w'))
print('discordant for adjudication (broken-relevant or U-involved):', len(disc))
for k in ['2100000250466#24', '2100000274694#2', '2100000274694#3', '2100000274694#4']:
    if k in G: print('control', k, 'sonnet', S[k]['article_status'], 'gpt', G[k]['article_status'])
