import json,sys
a,b=int(sys.argv[1]),int(sys.argv[2])
L=[json.loads(l) for l in open('s2_chunk021.jsonl')]
def cp(c,ind=''):
    s=f"{ind}[{c['key']}] {c['law']} {c['article']}({c.get('title')}) cited_as={c.get('cited_as')}\n{ind}{c['text']}\n"
    for d in c.get('delegated_from',[]) or []:
        s+=f"{ind} <-FROM {d.get('src',d) if isinstance(d,dict) else d}\n"
    for d in c.get('delegates_to',[]) or []:
        t=d.get('tgt',d)
        s+=f"{ind} ->TO line={d.get('line')} [{t.get('key')}] {t.get('law')} {t.get('article')}: {t.get('text')}\n"
    return s
for i in range(a,b):
    p=L[i]
    print('=====',i,p['packet_id'],p['rule_title'],p['rule_type'],p['article'])
    print('ART:',p['article_text']);print('PURP:',p['purpose_clause'])
    for c in p.get('cited_provisions',[]): print(cp(c))
    for k in p:
        if k not in('packet_id','rule_title','rule_type','article','article_title','article_text','purpose_clause','cited_provisions'):
            print(k,':',json.dumps(p[k],ensure_ascii=False)[:3000])
